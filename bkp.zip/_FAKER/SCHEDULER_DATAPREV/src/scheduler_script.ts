import axios from 'axios';

const URL = 'http://localhost:3010/eventos/obter-propostas';
const INTERVALO_MS = 60 * 1000; // 1 minuto

async function chamarEndpoint(cenario: string) {
  try {
    if (cenario == "X") {
      console.log(`[${new Date().toISOString()}] ❌ Simulando cronjob fora`);
    }
    else {
      const response = await axios.post(URL + "?cenario=" + cenario, {}); // POST vazio
      console.log(`[${new Date().toISOString()}] ✅ POST enviado com sucesso`);
      console.log(`Status: ${response.status}`);
    }    
  } catch (error: any) {
    console.error(`[${new Date().toISOString()}] ❌ Erro ao chamar endpoint`);
    if (error.response) {
      console.error(`Status: ${error.response.status} - ${error.response.statusText}`);
    } else {
      console.error(error.message);
    }
  }
}

const main_script =  {
  data: [
    {
      cenario: "N", info: "primeira chamada", minuto: "09:00"      
    },
    {
      cenario: "N", info: "chamada normal", minuto: "09:01"      
    },
    {
      cenario: "X", info: "cronjob fora", minuto: "09:02"      
    },    
    {
      cenario: "BR", info: "simular bad request", minuto: "09:03"      
    },    
    {
      cenario: "SLOW", info: "chamar", minuto: "09:04"      
    },    
  ]
}

console.log(`⏱️ SCHEDULER_DATAPREV script — chamando ${URL} a cada ${INTERVALO_MS / 1000} segundos`);

for (const item of main_script.data) 
  await chamarEndpoint(item.cenario)
