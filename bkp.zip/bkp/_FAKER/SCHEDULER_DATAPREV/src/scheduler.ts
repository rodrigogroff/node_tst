import axios from 'axios';

const URL = 'http://localhost:3010/eventos/obter-propostas';
const INTERVALO_MS = 60 * 1000; // 1 minuto

async function chamarEndpoint() {
  try {
    const response = await axios.post(URL, {}); // POST vazio
    console.log(`[${new Date().toISOString()}] ✅ POST enviado com sucesso`);
    console.log(`Status: ${response.status}`);
  } catch (error: any) {
    console.error(`[${new Date().toISOString()}] ❌ Erro ao chamar endpoint`);
    if (error.response) {
      console.error(`Status: ${error.response.status} - ${error.response.statusText}`);
    } else {
      console.error(error.message);
    }
  }
}

console.log(`⏱️ SCHEDULER_DATAPREV — chamando ${URL} a cada ${INTERVALO_MS / 1000} segundos`);
chamarEndpoint(); // primeira chamada imediata

