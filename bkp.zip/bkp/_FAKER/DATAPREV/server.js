import express from 'express';
import { faker } from '@faker-js/faker';
import { gerarPessoaSintetica } from './utils/cpfNameGenerator.js';

const app = express();
const port = process.env.PORT || 3031;

// util para converter date → DDMMYYYY
function formatDDMMYYYY(date) {
  if (!date) return null;
  const d = new Date(date);
  return (
    String(d.getDate()).padStart(2, '0') +
    String(d.getMonth() + 1).padStart(2, '0') +
    d.getFullYear()
  );
}

// util para gerar data/hora → DDMMYYYYHHMMSS
function formatDDMMYYYYHHMMSS(date) {
  const d = new Date(date);
  return (
    String(d.getDate()).padStart(2, '0') +
    String(d.getMonth() + 1).padStart(2, '0') +
    d.getFullYear() +
    String(d.getHours()).padStart(2, '0') +
    String(d.getMinutes()).padStart(2, '0') +
    String(d.getSeconds()).padStart(2, '0')
  );
}

app.get('/mock/dataprev/propostas', async (req, res) => {

  const pageRequired = parseInt(req.query.nroPagina || '1', 10);
  const dataHoraInicio = req.query.dataHoraInicio;
  const dataHoraFim = req.query.dataHoraFim;

  // 30% das requisições vão sofrer delay de 3 a 7 segundos (bem realista)
  if (Math.random() < 0.30) {
    const delayMs = faker.number.int({ min: 3000, max: 7000 });
    console.log(`Simulando lentidão do Dataprev... aguardando ${delayMs}ms (página ${pageRequired})`);
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }
  else if (Math.random() < 0.10) {
    const delayMs = faker.number.int({ min: 6000, max: 9000 });
    console.log(`Simulando lentidão do Dataprev... aguardando ${delayMs}ms (página ${pageRequired})`);
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }
  else{
    const delayMs = faker.number.int({ min: 100, max: 400 });
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }

  // simular bad request
  if (Math.random() < 0.01) { 
    console.log(`SIMULANDO 400 BAD REQUEST na página`);
    return res.status(400).json({
      timestamp: new Date().toISOString(),
      status: 400,
      error: "Bad Request",
      message: "teste....",
      path: "/propostas"
    });
  }

  console.log('pageRequired ' + pageRequired + " >> dataHoraInicio " + dataHoraInicio + " >> dataHoraFim " + dataHoraFim)

  const qtd = 250;

  const pessoas = [];
  const seen = new Set();

  while (pessoas.length < qtd) {

    const p = gerarPessoaSintetica();
    if (seen.has(p.cpf)) continue;
    seen.add(p.cpf);

    // Gera empresa atual (1 vínculo apenas, simplificado para layout)
    const empresaCnpj = faker.string.numeric(14);

    // salário bruto
    const salarioBruto = Number((Math.random() * 3000 + 2000).toFixed(2));

    // parcelas
    const nroParcelas = faker.number.int({ min: 6, max: 24 });

    // regra dos 30%
    const parcelaMax = salarioBruto * 0.30;
    const valorLiberadoMax = parcelaMax * nroParcelas;

    const valorLiberado = Number(
      (Math.random() * valorLiberadoMax).toFixed(2)
    );

    // idade com regra de 40% <18
    const age = Math.random() < 0.4
      ? faker.number.int({ min: 16, max: 17 })
      : faker.number.int({ min: 18, max: 90 });

    const dataNascimentoISO = faker.date
      .birthdate({ min: age, max: age, mode: 'age' });

    const dataAdmissao = faker.date.past({ years: faker.number.int({ min: 1, max: 10 }) });

    const idSolic = faker.number.int({ min: 1000, max: 9999 });

    let alertas = []

    // em 20% dos casos...
    if (Math.random() < 0.2) {
      // doença
      if (Math.random() < 0.5) {
        alertas.push ({ 
          "tipoAlerta": { "codigo": 1, "descricao": "Afastamento" }, 
          "dataReferencia": "2025-02-11", 
          "idEvento": 123456, 
          "codigoMotivoAfastamento": 3, 
          "dataAfastamento": "2025-02-11", 
          "dataTerminoAfastamento": "2025-03-11" 
        })
      // ou aviso prévio
      } else {
        alertas.push ({ 
          "tipoAlerta": { "codigo": 2, "descricao": "Desligamento" }, 
          "dataReferencia": "2025-02-11", 
          "idEvento": 789012, 
          "codigoMotivoDesligamento": 1, 
          "dataDesligamento": "2025-02-11", 
          "dataAvisoPrevio": "2025-01-11", 
          "dataFimAvisoPrevio": "2025-02-11" 
        })
      }
    }

    pessoas.push({
      idSolicitacao: idSolic,
      cpf: Number(p.cpf),
      matricula: `MATCEN${p.cpf.slice(-3)}`,
      inscricaoEmpregador: {
        codigo: 1,
        descricao: "CNPJ"
      },
      numeroInscricaoEmpregador: Number(empresaCnpj),
      valorLiberado,
      nroParcelas,
      dataHoraValidadeSolicitacao: formatDDMMYYYYHHMMSS(faker.date.future()),
      nomeTrabalhador: p.nome.toUpperCase(),
      dataNascimento: formatDDMMYYYY(dataNascimentoISO),
      margemDisponivel: Number((salarioBruto * 0.5).toFixed(2)),
      elegivelEmprestimo: Math.random() < 0.7,  // 70% elegível
      dataAdmissao: formatDDMMYYYY(dataAdmissao),
      alertas: alertas
    });
  }

  res.json([{
    nroPaginaAtual: pageRequired,
    nroTotalPaginas: faker.number.int({ min: 21, max: 40 }),
    nroTotalRegistros: qtd,
    qtdRegistrosPorPagina: qtd,
    qtdRegistrosPaginaAtual: qtd,
    dataHoraInicio: formatDDMMYYYYHHMMSS(new Date(Date.now() - 86400000)),
    dataHoraFim: formatDDMMYYYYHHMMSS(new Date()),
    conteudo: pessoas
  }]);
});

app.listen(port, () => {
  console.log(`Mock DataPrev server rodando em http://localhost:${port}`);
});
