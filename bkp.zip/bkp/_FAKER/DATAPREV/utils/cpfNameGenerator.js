// utils/cpfNameGenerator.js
// npm: instalar @faker-js/faker para nomes realistas
// npm install @faker-js/faker

import { faker } from '@faker-js/faker';

/**
 * Gera um CPF válido (dígitos verificadores calculados).
 * Retorna string sem formatação: '12345678909'
 */
export function gerarCpfNumeros() {
  // gera os 9 primeiros dígitos aleatoriamente (0-9)
  const nums = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10));

  // função que calcula um dígito verificador a partir de uma sequência e pesos
  function calcDigit(base) {
    let sum = 0;
    for (let i = 0; i < base.length; i++) {
      sum += base[i] * (base.length + 1 - i);
    }
    const mod = sum % 11;
    return mod < 2 ? 0 : 11 - mod;
  }

  const d1 = calcDigit(nums);
  const d2 = calcDigit([...nums, d1]);

  return nums.join('') + String(d1) + String(d2);
}

/**
 * Formata CPF para '000.000.000-00'
 */
export function formatarCpf(cpfNumeros) {
  return cpfNumeros.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

/**
 * Gera um objeto com nome e cpf (cpf tanto formatado quanto sem formatação).
 * nameLocale pode ser 'pt_BR' etc; faker já fornece nomes realistas.
 */
export function gerarPessoaSintetica() {
  // gerar nome com faker
  const nome = faker.person.fullName(); // @faker-js/faker v8+ uses faker.person
  const cpfNums = gerarCpfNumeros();
  return {
    nome,
    cpf: cpfNums,
    cpfFormatado: formatarCpf(cpfNums),
    dataGeracao: new Date().toISOString()
  };
}
