import express from 'express';
import { faker } from '@faker-js/faker';
import { gerarPessoaSintetica } from './utils/cpfNameGenerator.js';

const app = express();
const port = process.env.PORT || 3031;

app.get('/mock/dataprev/propostas', (req, res) => {
  
  const pageRequired = req.query.page;
  const qtd = Math.max(1, Math.min(1000, parseInt(req.query.records || '10', 10)));

  const pessoas = [];
  const seen = new Set();

  while (pessoas.length < qtd) {

    const p = gerarPessoaSintetica();

    if (seen.has(p.cpf)) continue;
    
    seen.add(p.cpf);

    // GERAR ENTRE 1 E 3 VÍNCULOS EMPREGATÍCIOS
    let empresas = Array.from({ length: faker.number.int({ min: 1, max: 3 }) }, () => {

      // 30% < 360 dias, 70% entre 361 e 3650 dias
      const isRecent = Math.random() < 0.3;
      const daysAgo = isRecent
        ? faker.number.int({ min: 1, max: 360 })
        : faker.number.int({ min: 361, max: 3650 });

      const dataInicioEmpresa = faker.date.recent({ days: daysAgo });

      // Data início estilo Dataprev
      const data_inicio = faker.date.past({
        years: faker.number.int({ min: 1, max: 10 })
      });

      // Pessoa ainda está trabalhando
      const aindaTrabalhando = faker.datatype.boolean();

      const data_fim = aindaTrabalhando
        ? null
        : faker.date.between({ from: data_inicio, to: new Date() });

      const valorBruto = Number((Math.random() * 3000 + 1000).toFixed(2));
      const valorLiquido = Number((valorBruto * 0.7).toFixed(2));

      // DISTRIBUIÇÃO DA CATEGORIA DO TRABALHADOR
      const r = Math.random();
      let categoria = 101;

      if (r < 0.60) categoria = 101;
      else if (r < 0.75) categoria = 201;
      else if (r < 0.85) categoria = 203;
      else if (r < 0.95) categoria = 104;
      else categoria = 999; // 5% categoria rara

      return {
        nome_empresa: faker.company.name(),
        cnpj: faker.string.numeric(14),
        dataInicioEmpresa,
        data_inicio: data_inicio.toISOString().slice(0, 10),
        data_fim: data_fim ? data_fim.toISOString().slice(0, 10) : null,
        categoriaTrabalhador: categoria,
        valorBruto,
        valorLiquido,
        cargo: faker.helpers.arrayElement([
          'ANALISTA',
          'PROJETISTA',
          'ORACLE EXPERT',
          'DEV',
          'DEV SR',
          'ADMIN REDE',
          'CTO'
        ]),
      };
    });

    // ORDENAR POR DATA INÍCIO ASC
    empresas.sort((a, b) => new Date(a.data_inicio) - new Date(b.data_inicio));

    // A ÚLTIMA EMPRESA É ATUAL (data_fim = null)
    empresas[empresas.length - 1].data_fim = null;

    // IDADE — 40% com 16–17 anos
    const age = Math.random() < 0.4
      ? faker.number.int({ min: 16, max: 17 })
      : faker.number.int({ min: 18, max: 90 });

    const dataNascimento = faker.date
      .birthdate({ min: age, max: age, mode: 'age' })
      .toISOString()
      .slice(0, 10);

    // -----------------------------------------
    // REGRA: PARCELA NUNCA > 30% DO SALÁRIO BRUTO ATUAL
    // -----------------------------------------
    const salarioBrutoAtual = empresas[empresas.length - 1].valorBruto;
    const parcelas = faker.number.int({ min: 6, max: 24 });

    const parcelaMaxima = salarioBrutoAtual * 0.30;
    const valorSolicitadoMax = parcelas * parcelaMaxima;

    const valorSolicitado = Number(
      (Math.random() * valorSolicitadoMax).toFixed(2)
    );
    // -----------------------------------------

    pessoas.push({
      idSolicitacao: `S${Date.now().toString(36)}${faker.string.alphanumeric(4)}`,
      nome: p.nome.toUpperCase(),
      cpf: p.cpf,
      cpfFormatado: p.cpfFormatado,
      dataNascimento,
      valorSolicitado,
      parcelas,
      nacionalidade: Math.random() < 0.3 ? 'ESTRANGEIRO' : 'BRASILEIRO',
      elegibiliade: Math.random() < 0.3 ? 'N' : 'S',
      status: faker.helpers.arrayElement([
        'EM_ANALISE',
        'APROVADA',
        'REPROVADA',
        'CANCELADA',
        'PENDENTE',
        'RESERVADA',
        'FORMALIZADA'
      ]),
      dataSolicitacao: new Date().toISOString(),
      empresas
    });
  }

  res.json({
    pagina: pageRequired,
    tamanhoPagina: qtd,
    totalPaginas: 7,
    totalRegistros: qtd,
    solicitacoes: pessoas
  });
});

app.listen(port, () => {
  console.log(`Mock DataPrev server rodando em http://localhost:${port}`);
});
