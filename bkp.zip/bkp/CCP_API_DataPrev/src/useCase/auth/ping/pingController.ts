import { NextFunction, Request, Response } from 'express';
import { PingUseCase } from './pingUseCase';

import { 
  IPingRequestDTO, PingRequestSchema, 
  IPingResponseDTO, PingResponseSchema 
} from './ping.schema';

export class PingController {

  constructor(private pingUseCase: PingUseCase) {}

  async handle(request: Request, response: Response, next: NextFunction): Promise<Response> {
    try {

      var input: IPingRequestDTO = PingRequestSchema.parse(request.body);

      const sucesso = await this.pingUseCase.execute(input);

      var output: IPingResponseDTO = PingResponseSchema.parse({
        mensagem: "Pong!"
      });

      return response.status(200).json(output);

    } catch (error) {
      console.error("Erro no CreateUserController:", error);
      next(error);
    }
  }
}
