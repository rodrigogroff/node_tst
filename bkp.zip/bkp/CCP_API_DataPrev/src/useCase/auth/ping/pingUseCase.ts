import { IPingRequestDTO } from './ping.schema';

export class PingUseCase {
  
  constructor() {}

  async execute(data: IPingRequestDTO): Promise<boolean> {
    
    try {
      
      return true;

    } catch (error) {
      
      throw new Error("Falha ao criar usuário.");
    }
  }
}
