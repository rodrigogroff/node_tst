import { z } from 'zod';
import { extendZodWithOpenApi } from '@asteasolutions/zod-to-openapi';
extendZodWithOpenApi(z);

export const PingRequestSchema = z.object({
  
});

export type IPingRequestDTO = z.infer<typeof PingRequestSchema>;

export const PingResponseSchema = z.object({
  mensagem: z
    .string()
    .openapi({ description: 'Mensagem do sistema', example: 'Pong' }),
});

export type IPingResponseDTO = z.infer<typeof PingResponseSchema>;
