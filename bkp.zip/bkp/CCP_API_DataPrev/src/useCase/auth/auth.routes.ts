import 'module-alias/register';
import { Router } from 'express';

import { PingUseCase } from './ping/pingUseCase';
import { PingController } from './ping/pingController';

const pingUseCase = new PingUseCase();
const pingController = new PingController(pingUseCase);

const authRoutes = Router();

authRoutes.post('/ping', (req, res, next) => pingController.handle(req, res, next));

export { authRoutes };
