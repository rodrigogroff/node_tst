import { PingController } from './ping/pingController';
import { PingUseCase } from './ping/pingUseCase';

const pingUseCase = new PingUseCase();
const pingController = new PingController(pingUseCase);

export { 
  pingController, pingUseCase,
};
