
import { OraclePessoaRepository } from '../../repositories/pessoaRepository/OraclePessoaRepository';
import { OracleTransacaoRepository } from '../../repositories/transacaoRepository/OracleTransacaoRepository';

import { ObterPropostasController } from './obter-propostas/obterPropostasController';
import { ObterPropostasUseCase } from './obter-propostas/obterPropostasUseCase';

const pessoaRepository = OraclePessoaRepository.getInstance();
const transacaoRepository = OracleTransacaoRepository.getInstance();

const obterPropostasUseCase = new ObterPropostasUseCase(pessoaRepository, transacaoRepository);
const obterPropostasController = new ObterPropostasController(obterPropostasUseCase);

export { 
  obterPropostasController, obterPropostasUseCase,
};
