import { NextFunction, Request, Response } from 'express';
import { ObterPropostasUseCase } from './obterPropostasUseCase';

import { 
  IObterPropostasRequestDTO, ObterPropostasRequestSchema, 
  IObterPropostasResponseDTO, ObterPropostasResponseSchema 
} from './obterPropostas.schema';

export class ObterPropostasController {

  constructor(private obterPropostasUseCase: ObterPropostasUseCase) {}

  async handle(request: Request, response: Response, next: NextFunction): Promise<Response> {
    try {

      var input: IObterPropostasRequestDTO = ObterPropostasRequestSchema.parse(request.body);

      const sucesso = await this.obterPropostasUseCase.execute(input);

      var output: IObterPropostasResponseDTO = ObterPropostasResponseSchema.parse({
        mensagem: "Processamento OK"
      });

      return response.status(200).json(output);

    } catch (error) {
      console.error("Erro no CreateUserController:", error);
      next(error);
    }
  }
}
