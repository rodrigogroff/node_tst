import axios from "axios";
import http from "http";
import { v4 as uuidv4 } from "uuid";

import { IPessoaRepository } from "@src/repositories/pessoaRepository/IPessoaRepository";
import { ITransacaoRepository } from "@src/repositories/transacaoRepository/ITransacaoRepository";
import { IObterPropostasRequestDTO } from "./obterPropostas.schema";

export class ObterPropostasUseCase {

  constructor(
    private pessoaRepository: IPessoaRepository,
    private transacaoRepository: ITransacaoRepository
  ) {}

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  private guid = () => uuidv4();
  private nowISO = () => new Date().toISOString();

  private pad2 = (n: number) => String(n).padStart(2, "0");

  private formatDateTime = (d: Date) =>
    `${this.pad2(d.getDate())}${this.pad2(d.getMonth() + 1)}${d.getFullYear()}${this.pad2(
      d.getHours()
    )}${this.pad2(d.getMinutes())}${this.pad2(d.getSeconds())}`;

  private normalizeCpf = (cpf: any) =>
    (cpf ?? "").toString().replace(/\D/g, "").padStart(11, "0");

  private normalizeCnpj = (cnpj: any) =>
    (cnpj ?? "").toString().replace(/\D/g, "");

  private convertDPDate = (raw: string) =>
    `${raw.substring(4, 8)}-${raw.substring(2, 4)}-${raw.substring(0, 2)}`;

  private formatMs = (num: number) =>
    num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

  private async runBatch<T>( items: T[], batchSize: number, handler: (item: T) => Promise<void>) {
    for (let i = 0; i < items.length; i += batchSize) 
      await Promise.all(items.slice(i, i + batchSize).map(handler));    
  }

  private criarNovaTransacao = async (pid: string) =>
    this.transacaoRepository.createTransacao({
      pid,
      dt_log: this.nowISO(),
      ext_pf_id: null,
      dt_fim: null,
      info: ".",
      jornada: "BUSCA_PROPOSTAS",
      ms: "DATAPREV",
      sucesso: null,
    });

  private atualizarTransacao = async (dt_log: string, dt_fim: string, info: string, pid: string, sucesso: string) =>
    await this.transacaoRepository.updateTransacao({ 
            dt_log: dt_log,
            dt_fim: dt_fim,
            info: info,             
            pid: pid,
            sucesso: sucesso
          });

  // ---------------------------------------------------------------------------
  // EXECUTE (de 1 em 1 minuto)
  // ---------------------------------------------------------------------------

  async execute(data: IObterPropostasRequestDTO): Promise<boolean> {

    const URL_DATAPREV = `${process.env.BASE_URL_DATAPREV}/mock/dataprev/propostas`;

    // variaveis de mt
    const maxThreadsPages = 4;
    const maxThreadsInserts = 4;

    // process id desta transação
    let pid = this.guid();

    // padrão de data de inicio: processar dois minutos atrás
    let dt_inicio_proc = Date.now() - 2 * 60 * 1_000;
    // padrão de data de fim: agora
    let dt_fim_proc = Date.now();

    // calculo estatístico
    let stat_totalNovasPessoas = 0;
    let stat_totalRecorrentes = 0;
    let stat_totalInelegiveis = 0;
    let stat_dt_inicio = Date.now();

    // variaveis de quebra
    let bRecoveryMode = false;
    let bRecoveryDone = false;

    const httpAgent = new http.Agent({ keepAlive: true });
    const axiosInstance = axios.create({ httpAgent });

    // messaging
    const MSG_CRASH_DONE = "Crash recovery done";
    const MSG_CRASH = "Crash";

    try {

      // ---------------------------------------------------------------------
      // 1 — semaforo de estado da ultima transação "S1"
      // ---------------------------------------------------------------------
        
      const ultimaTransacao = (await this.transacaoRepository.getTransacaoDataprevObterproposta({}))?.result;

      if (!ultimaTransacao) {

        // #S1A -- primeira transação  >>>> caminho okay 1 <<<<<<
        await this.criarNovaTransacao(pid);
      
      } else {

        // já possui transações, verificar tempo elapsed
        const dtStart = new Date(ultimaTransacao.DT_LOG as any);
        const msElapsed = Date.now() - dtStart.getTime();

        // verifica situação da ultima transação (aberta ou fechada)
        const bTransacaoFechada = ultimaTransacao.DT_FIM != null

        if (bTransacaoFechada) {          

          if (msElapsed < 2 * 60 * 1_000) {
            // #S1B -- FECHADA há menos de 2 minutos >>> caminho okay 2 <<<<<<
            await this.criarNovaTransacao(pid);
          }          

          else if (msElapsed > 2 * 60 * 1_000) {
            // #S1D -- FECHADA acima de 2 minutos
            await this.criarNovaTransacao(pid);
            bRecoveryMode = true; // estamos em recuperação
            dt_inicio_proc = new Date(ultimaTransacao.DT_LOG).getTime();  
            // recomeçar desde a data de parada            
            dt_fim_proc = dt_inicio_proc + 10 * 60 * 1_000; // trabalhar em lotes de dez minutos            
            // se finalmente chegou a hora atual
            if (dt_fim_proc > stat_dt_inicio) {
              bRecoveryDone = true;
              dt_fim_proc = stat_dt_inicio; // não ultrapassar dt de hoje
            }
          }
        
        } else {  // ultima transação ficou aberta
          
          if (msElapsed >= 30 * 60 * 1_000) {
            // #S1C -- ABERTA acima de 30 minutos
            bRecoveryMode = true; // estamos em recuperação
            pid = ultimaTransacao.PID;  // usar mesmo PID da transação que morreu!
            // recomeçar desde a data de parada
            dt_inicio_proc = new Date(ultimaTransacao.DT_LOG).getTime(); 
            dt_fim_proc = dt_inicio_proc + 10 * 60 * 1_000; // trabalhar em lotes de dez minutos
            // se finalmente chegou a hora atual
            if (dt_fim_proc > stat_dt_inicio) {
              bRecoveryDone = true; 
              dt_fim_proc = stat_dt_inicio; // não ultrapassar dt de hoje
            }
          }
          else {
            // #S1D -- ABERTA há menos de 30 minutos
            // ms ainda processando, não interromper e sair
            return false;
          }          
        }
      }

      // ---------------------------------------------------------------------
      // 2 — consulta Dataprev (primeira página)
      // ---------------------------------------------------------------------
      
      const queryParams =
        `${URL_DATAPREV}?codigoSolicitante=55` +
        `&dataHoraInicio=${this.formatDateTime(new Date(dt_inicio_proc))}` +
        `&dataHoraFim=${this.formatDateTime(new Date(dt_fim_proc))}`;

      let totalPaginas = 0;
      let firstPageResp;

      try {
        firstPageResp = await axiosInstance.get(queryParams + "&nroPagina=1");
        totalPaginas = firstPageResp?.data?.[0]?.nroTotalPaginas ?? 0;
      } catch {
        return false;
      }

      if (totalPaginas <= 0)
        return false;      

      // ---------------------------------------------------------------------
      // 5 — buscar páginas concorrentemente (reutilizando a primeira)
      // ---------------------------------------------------------------------
      
      const t_fetch = Date.now();

      // reuse first page
      const pagesResponses: any[] = [firstPageResp]; 

      // pages 2..N
      const pageNumbers = Array.from({ length: totalPaginas - 1 }, (_, i) => i + 2 );

      for (let i = 0; i < pageNumbers.length; i += maxThreadsPages) {
        const chunk = pageNumbers.slice(i, i + maxThreadsPages);
        const result = await Promise.allSettled( chunk.map((p) => axiosInstance.get(queryParams + "&nroPagina=" + p)) );
        for (const r of result) 
          if (r.status === "fulfilled") 
            pagesResponses.push(r.value);        
          else
            // bad request ou qualquer erro
            return false; // deixar a transação aberta até ter todas as páginas!
      }

      if (pagesResponses.length === 0)
        // nada a fazer, nenhuma proposta
        return true;

      const elapsed_fetch = Date.now() - t_fetch;

      // ---------------------------------------------------------------------
      // 6 — extrair solicitações elegíveis
      // ---------------------------------------------------------------------

      const memorySolicitacoes: any[] = [];

      for (const resp of pagesResponses) {
        const conteudo = resp.data?.[0]?.conteudo ?? [];
        for (const s of conteudo) {
          if (!s.elegivelEmprestimo) {
            stat_totalInelegiveis++;
            continue;
          }
          if (s.alertas?.length > 0) {
            stat_totalInelegiveis++;
            continue;
          }
          s.cpf = this.normalizeCpf(s.cpf);
          s.numeroInscricaoEmpregador = this.normalizeCnpj(s.numeroInscricaoEmpregador);
          memorySolicitacoes.push(s);
        }
      }

      if (memorySolicitacoes.length === 0) {
        await this.transacaoRepository.updateTransacao({
          dt_log: new Date(stat_dt_inicio).toISOString(),
          dt_fim: this.nowISO(),
          info: "Nenhuma solicitação elegível",
          pid,
          sucesso: "N",
        });
        return false;
      }

      // ---------------------------------------------------------------------
      // 7 — buscar dados já existentes no banco
      // ---------------------------------------------------------------------
      
      const t_db = Date.now();

      const cpfs = [...new Set(memorySolicitacoes.map((s) => s.cpf))];
      const propostasDB = await this.pessoaRepository.getPessoaPropostasByCPFS({ cpfs });
      const propostasPorCpf = new Map( (propostasDB?.results ?? []).map((r: any) => [r.CPF, r.EXT_PF_ID]) );
      const ctpsDB = await this.pessoaRepository.getPessoaCTPSVEByCPFS({ cpfs });
      const ctpsKeys = new Set(
        (ctpsDB?.results ?? []).map(
          (r: any) => `${r.CPF}|${r.CNPJ}`
        )
      );

      const elapsed_db = Date.now() - t_db;

      // ---------------------------------------------------------------------
      // 8 — processar solicitações
      // ---------------------------------------------------------------------

      const t_insert = Date.now();

      const handler = async (s: any) => {

        const cpf = s.cpf;
        const cnpj = s.numeroInscricaoEmpregador;

        let pf_id = this.guid();

        // já retornar o EXT_PF_ID
        const existePFID = propostasPorCpf.get(cpf);

        if (!existePFID) {

          stat_totalNovasPessoas++;

          await this.pessoaRepository.createPessoa({
            pid,
            ext_pf_id: pf_id,
            email: ".",
            nome_completo: s.nomeTrabalhador,
            primeiro_nome: ".",
            sobre_nome: ".",
            nome_pai: ".",
            nome_mae: ".",
            dt_nascimento: this.convertDPDate(s.dataNascimento),
            cpf,
            rg: ".",
            pis: ".",
            pasep: ".",
            nit: ".",
            nacionalidade: ".",
            cidade_natural: ".",
            estado_natural: ".",
            sexo: "M",
            estado_civil: "SOLTEIRO",
            endereco: ".",
            endereco_num: ".",
            endereco_compl: ".",
            cep: ".",
            dt_criacao: this.nowISO(),
            dt_alteracao: null,
          });

          await this.pessoaRepository.createPessoaProposta({
            pid,
            cpf,
            id_dataprev: s.idSolicitacao,
            dt_criacao: this.nowISO(),
            ext_pf_id: pf_id,
            fk_situacao_atual: 1,
            parcelas: s.nroParcelas,
            valor_solicitado: s.valorLiberado,
          });
          
        } 
        else {
          stat_totalRecorrentes++;
          pf_id = existePFID;
        }

        // Criar CTPS se não existir
        const key = `${cpf}|${cnpj}`;

        if (!ctpsKeys.has(key)) {
          await this.pessoaRepository.createPessoaCTPS({
            pid,
            ext_pf_id: pf_id,
            cargo: ".",
            cpf,
            cnpj,
            dt_criacao: this.nowISO(),
            dt_alteracao: null,
            dt_fim: null,
            dt_inicio: this.convertDPDate(s.dataAdmissao),
            vr_bruto: "0",
            vr_liquido: s.margemDisponivel,
            nome_empresa: ".",
          });

          ctpsKeys.add(key);
        }
      };

      await this.runBatch(memorySolicitacoes, maxThreadsInserts, handler);

      const elapsed_insert = Date.now() - t_insert;

      // ---------------------------------------------------------------------
      // 9 — finaliza transação
      // ---------------------------------------------------------------------

      // - salvar estatisticas
      const info = `
Processo concluído! 
Novos......:      ${stat_totalNovasPessoas} 
Recorrentes:      ${stat_totalRecorrentes} 
Descartes..:      ${stat_totalInelegiveis} 
Tempo dataprev..: ${this.formatMs(elapsed_fetch)} 
Tempo db query..: ${this.formatMs(elapsed_db)} 
Tempo inserts...: ${this.formatMs(elapsed_insert)} -- ms (${(elapsed_insert / stat_totalNovasPessoas).toFixed(2)}) 
Tempo total.....: ${this.formatMs(Date.now() - stat_dt_inicio)} 
Recovery........: ${bRecoveryMode}
Recovery done...: ${bRecoveryDone}
`;

      // se houve alguma perda (crash, sistema fora por um longo tempo)
      if (bRecoveryMode) {
        // se chegou até a data e hora de hoje
        if (bRecoveryDone) {          
          // finaliza a transação
          await this.atualizarTransacao(new Date(dt_fim_proc).toISOString(), new Date(dt_fim_proc).toISOString(), info, pid, 'S' )
        } else {
          // deixar para proximo cronjob puxar mais dez minutos          
          await this.atualizarTransacao(new Date(dt_fim_proc).toISOString(), null, info, pid, null )
        }
      } else {
        // processo normal chegou ao fim
        await this.atualizarTransacao(new Date(dt_inicio_proc).toISOString(), this.nowISO(), info, pid, 'S' )
      }      
      // fim
      return true;
    }

    // ------------------------------
    // ERROR HANDLER
    // ------------------------------
    
    catch (err: any) {

      console.log("#error obterPropostas", err);

      await this.transacaoRepository.updateTransacao({
        dt_log: new Date(dt_inicio_proc).toISOString(),
        dt_fim: this.nowISO(),
        info: "FALHA: " + (err?.message ?? String(err)),
        pid,
        sucesso: "N",
      });

      return false;
    }

    // ------------------------------
    // Fim
    // ------------------------------

    finally {
      try { httpAgent.destroy(); } catch {}
    }
  }
}
