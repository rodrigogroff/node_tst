import { ObterPropostasUseCase } from "./obterPropostasUseCase";
import axios from "axios";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe("ObterPropostasUseCase - execute()", () => {
  let pessoaRepository: any;
  let transacaoRepository: any;

  beforeEach(() => {
    
    jest.clearAllMocks();

    pessoaRepository = {
      getPessoaPropostasByCPFS: jest.fn().mockResolvedValue({ results: [] }),
      getPessoaCTPSVEByCPFS: jest.fn().mockResolvedValue({ results: [] }),

      createPessoa: jest.fn().mockResolvedValue(true),
      createPessoaProposta: jest.fn().mockResolvedValue(true),
      createPessoaCTPS: jest.fn().mockResolvedValue(true),
    };

    transacaoRepository = {
      getTransacaoDataprevObterproposta: jest.fn().mockResolvedValue(null),
      createTransacao: jest.fn().mockResolvedValue(true),
      updateTransacao: jest.fn().mockResolvedValue(true),
    };
  });

  it("deve executar o fluxo completo com sucesso", async () => {

    process.env.BASE_URL_DATAPREV = "http://fake-dp";
    process.env.BASE_URL_MS_PREQUALIFICACAO = "http://fake-ms";

    const useCase = new ObterPropostasUseCase(
      pessoaRepository,
      transacaoRepository
    );

    const fakeAxiosInstance = {
      post: jest.fn().mockResolvedValue({ data: {} }),
      get: jest.fn()
    };

    // Simula axios.create() retornando nossa instância mockada
    (axios.create as jest.Mock).mockReturnValue(fakeAxiosInstance as any);

    // ---- Mock primeira página (descobre totalPaginas = 1)
    fakeAxiosInstance.get.mockImplementationOnce(async () => ({
      data: [
        {
          nroTotalPaginas: 1,
          conteudo: [], // não usado na primeira página
        },
      ],
    }));

    // ---- Mock página 1 (conteúdo elegível)
    fakeAxiosInstance.get.mockImplementationOnce(async () => ({
      data: [
        {
          conteudo: [
            {
              idSolicitacao: "ABC",
              cpf: "11122233344",
              numeroInscricaoEmpregador: "12345678000190",
              dataNascimento: "25091981",
              dataAdmissao: "01012020",
              nroParcelas: 12,
              valorLiberado: 1500,
              margemDisponivel: "900",
              nomeTrabalhador: "João da Silva",
              elegivelEmprestimo: true,
            },
          ],
        },
      ],
    }));

    const result = await useCase.execute({} as any);

    expect(result).toBe(true);

    // --------------------------
    // Asserts essenciais:
    // --------------------------

    // 1. Não havia transação aberta
    expect(
      transacaoRepository.getTransacaoDataprevObterproposta
    ).toHaveBeenCalled();

    // 2. Criou transação inicial
    expect(transacaoRepository.createTransacao).toHaveBeenCalledTimes(1);

    // 3. Chamou MS pré-qualificação
    expect(fakeAxiosInstance.post).toHaveBeenCalledWith(
      "http://fake-ms/auth/ping",
      {}
    );

    // 4. Chamou Dataprev duas vezes (primeira página + página 1)
    expect(fakeAxiosInstance.get).toHaveBeenCalledTimes(2);

    // 5. Criou pessoa nova
    expect(pessoaRepository.createPessoa).toHaveBeenCalledTimes(1);

    // 6. Criou proposta
    expect(pessoaRepository.createPessoaProposta).toHaveBeenCalledTimes(1);

    // 7. Criou CTPS/VE
    expect(pessoaRepository.createPessoaCTPS).toHaveBeenCalledTimes(1);

    // 8. Finalizou transação
    expect(transacaoRepository.updateTransacao).toHaveBeenCalled();
  });
});
