import { z } from 'zod';
import { extendZodWithOpenApi } from '@asteasolutions/zod-to-openapi';
extendZodWithOpenApi(z);

export const ObterPropostasRequestSchema = z.object({
  
});

export type IObterPropostasRequestDTO = z.infer<typeof ObterPropostasRequestSchema>;

export const ObterPropostasResponseSchema = z.object({
  mensagem: z
    .string()
    .openapi({ description: 'Mensagem do sistema', example: 'Pong' }),
});

export type IObterPropostasResponseDTO = z.infer<typeof ObterPropostasResponseSchema>;
