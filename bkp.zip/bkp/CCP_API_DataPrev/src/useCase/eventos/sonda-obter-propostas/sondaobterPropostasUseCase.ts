import axios from "axios";
import http from "http";
import { v4 as uuidv4 } from 'uuid';
import { IPessoaRepository } from '@src/repositories/pessoaRepository/IPessoaRepository';
import { ITransacaoRepository } from '@src/repositories/transacaoRepository/ITransacaoRepository';
import { ISondaObterPropostasRequestDTO } from './sondaobterPropostas.schema';

export class SondaObterPropostasUseCase {
  
  constructor(private pessoaRepository: IPessoaRepository, private transacaoRepository: ITransacaoRepository) {}

  async execute(data: ISondaObterPropostasRequestDTO): Promise<boolean> {
    
    try {
      
      const generateGuid = (): string => uuidv4();

      const BASE_URL_DATAPREV =
        process.env.BASE_URL_DATAPREV + "/mock/dataprev/propostas";

      // agente HTTP com keepAlive
      const httpAgent = new http.Agent({ keepAlive: true });
      const axiosInstance = axios.create({ httpAgent });

      const response = await axiosInstance.get(BASE_URL_DATAPREV);

      setImmediate(() => {
        httpAgent.destroy();
      });

      return true;

    } catch (error) {

      return false
    }
  }
}
