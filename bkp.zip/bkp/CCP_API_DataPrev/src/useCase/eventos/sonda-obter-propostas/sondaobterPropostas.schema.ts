import { z } from 'zod';
import { extendZodWithOpenApi } from '@asteasolutions/zod-to-openapi';
extendZodWithOpenApi(z);

export const SondaObterPropostasRequestSchema = z.object({
  
});

export type ISondaObterPropostasRequestDTO = z.infer<typeof SondaObterPropostasRequestSchema>;

export const SondaObterPropostasResponseSchema = z.object({
  mensagem: z
    .string()
    .openapi({ description: 'Mensagem do sistema', example: 'Pong' }),
});

export type ISondaObterPropostasResponseDTO = z.infer<typeof SondaObterPropostasResponseSchema>;
