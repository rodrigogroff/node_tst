import { NextFunction, Request, Response } from 'express';
import { SondaObterPropostasUseCase } from './sondaobterPropostasUseCase';

import { 
  ISondaObterPropostasRequestDTO, SondaObterPropostasRequestSchema, 
  ISondaObterPropostasResponseDTO, SondaObterPropostasResponseSchema 
} from './sondaobterPropostas.schema';
import { badRequest } from '@src/helper/responses';

export class SondaObterPropostasController {

  constructor(private sondaobterPropostasUseCase: SondaObterPropostasUseCase) {}

  async handle(request: Request, response: Response, next: NextFunction): Promise<Response> {
    try {

      var input: ISondaObterPropostasRequestDTO = SondaObterPropostasRequestSchema.parse(request.body);

      const sucesso = await this.sondaobterPropostasUseCase.execute(input);

      var output: ISondaObterPropostasResponseDTO = SondaObterPropostasResponseSchema.parse({
        mensagem: "Processamento OK"
      });

      if (!sucesso)
        return badRequest(response, "Site indisponível");

      return response.status(200).json(output);

    } catch (error) {
      console.error("Erro no CreateUserController:", error);
      next(error);
    }
  }
}
