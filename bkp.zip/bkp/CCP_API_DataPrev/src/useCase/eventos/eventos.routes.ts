import 'module-alias/register';
import { Router } from 'express';
import { OraclePessoaRepository } from '@src/repositories/pessoaRepository/OraclePessoaRepository';
import { OracleTransacaoRepository } from '@src/repositories/transacaoRepository/OracleTransacaoRepository';

import { ObterPropostasUseCase } from './obter-propostas/obterPropostasUseCase';
import { ObterPropostasController } from './obter-propostas/obterPropostasController';

import { SondaObterPropostasUseCase } from './sonda-obter-propostas/sondaobterPropostasUseCase';
import { SondaObterPropostasController } from './sonda-obter-propostas/sondaobterPropostasController';

const pessoaRepository = OraclePessoaRepository.getInstance();
const transacaoRepository = OracleTransacaoRepository.getInstance();

const obterPropostasUseCase = new ObterPropostasUseCase(pessoaRepository, transacaoRepository);
const obterPropostasController = new ObterPropostasController(obterPropostasUseCase);

const sondaobterPropostasUseCase = new SondaObterPropostasUseCase(pessoaRepository, transacaoRepository);
const sondaobterPropostasController = new SondaObterPropostasController(sondaobterPropostasUseCase);

const eventosRoutes = Router();

eventosRoutes.post('/sonda-obter-propostas', (req, res, next) => sondaobterPropostasController.handle(req, res, next));
eventosRoutes.post('/obter-propostas', (req, res, next) => obterPropostasController.handle(req, res, next));

export { eventosRoutes };
