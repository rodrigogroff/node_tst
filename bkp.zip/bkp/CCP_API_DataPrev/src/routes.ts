import { Router } from 'express';
import { checkMW } from 'tpz-health';

import { eventosRoutes } from './useCase/eventos/eventos.routes';

const routes = Router();

routes.use('/eventos', eventosRoutes);

routes.get('/healths', checkMW);

export { routes };
