import oracledb from "oracledb";
import { app } from "./app";
import { logger } from "./bootstrap/logger";

process.env.UV_THREADPOOL_SIZE = "60";

// --------------------------------------------------
// 1. Inicializa Oracle Client UMA vez
// --------------------------------------------------
try {
  oracledb.initOracleClient({
    libDir: process.env.ORACLE_CLIENT_PATH, // se você usa instant client
  });

  logger.info("Oracle client initialized.");
} catch (err: any) {
  // NJS-045 → oracle client já inicializado → não é erro fatal
  if (!String(err.message).includes("NJS-045")) {
    logger.error("Fatal: failed to initialize Oracle client", err);
    process.exit(1);
  }
  //logger.warn("Oracle client already initialized.");
}

// --------------------------------------------------
// 2. Cria pool global (mainPool) UMA vez
// --------------------------------------------------
(async () => {
  try {
    await oracledb.createPool({
      user: process.env.NODE_ORACLEDB_USER,
      password: process.env.NODE_ORACLEDB_PASSWORD,
      connectString: `${process.env.NODE_ORACLEDB_DB_HOST}/${process.env.NODE_ORACLEDB_DB_NAME}`,
      poolAlias: "mainPool",
      poolMax: Number(process.env.NODE_ORACLEDB_POOL_MAX_SIZE) || 10,
      poolMin: 1,
      poolIncrement: 1
    });

    logger.info("Oracle connection pool created.");
  } catch (err) {
    logger.error("Fatal: could not create Oracle pool", err);
    process.exit(1);
  }

  // --------------------------------------------------
  // 3. Sobe o server Express somente após o pool estar pronto
  // --------------------------------------------------
  const port = Number(process.env.PORT) || 3010;

  logger.info(`App is running on port ${port}`);
  app.listen(port);
})();
