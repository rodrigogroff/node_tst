import { OpenAPIRegistry, OpenApiGeneratorV3 } from '@asteasolutions/zod-to-openapi';

import {
  PingRequestSchema,
  PingResponseSchema,
} from '../useCase/auth/ping/ping.schema';

import {
  ObterPropostasRequestSchema,
  ObterPropostasResponseSchema,
} from '../useCase/eventos/obter-propostas/obterPropostas.schema';

import {
  SondaObterPropostasRequestSchema,
  SondaObterPropostasResponseSchema,
} from '../useCase/eventos/sonda-obter-propostas/sondaobterPropostas.schema';

export const registry = new OpenAPIRegistry();

registry.register('PingRequest', PingRequestSchema);
registry.register('PingResponse', PingResponseSchema);

registry.register('ObterPropostasRequest', ObterPropostasRequestSchema);
registry.register('ObterPropostasResponse', ObterPropostasResponseSchema);

registry.register('SondaObterPropostasRequest', SondaObterPropostasRequestSchema);
registry.register('SondaObterPropostasResponse', SondaObterPropostasResponseSchema);

const generator = new OpenApiGeneratorV3(registry.definitions);

const components = generator.generateComponents();

export const zodSchemas = components.components.schemas;
