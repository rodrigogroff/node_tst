export const commonErrorResponses = {
  '400': {
    $ref: '#/components/responses/BadRequest',
  },
  '401': {
    $ref: '#/components/responses/Unauthorized',
  },
  '403': {
    $ref: '#/components/responses/Forbidden',
  },
  '404': {
    $ref: '#/components/responses/NotFound',
  },
  '405': {
    $ref: '#/components/responses/MethodNotAllowed',
  },
  '500': {
    $ref: '#/components/responses/InternalServerError',
  },
  '501': {
    $ref: '#/components/responses/NotImplemented',
  },
  '502': {
    $ref: '#/components/responses/BadGateway',
  },
  '503': {
    $ref: '#/components/responses/ServiceUnavailable',
  },
};
