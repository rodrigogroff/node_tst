import { commonErrorResponses } from './common-error-responses';

export const authPaths = {
  
  '/auth/ping': {
    post: {
      summary: 'Testa se MS está no ar',
      tags: ['Authorize'],
      requestBody: {
        description: 'Teste de disponibilidade.',
        required: true,
        content: {
          'application/json': {
            schema: {
              $ref: '#/components/schemas/PingRequest',
            },
          },
        },
      },
      responses: {
        '200': {
          description: 'Success.',
          content: {
            'application/json': {
              schema: {
                $ref: '#/components/schemas/PingResponse',
              },
            },
          },
        },
        ...commonErrorResponses,
      },
    },
  },

};
