import { commonErrorResponses } from './common-error-responses';

export const eventosPaths = {
  
  '/eventos/obter-propostas': {
    post: {
      summary: 'Dispara consulta de propostas na dataprev',
      tags: ['Authorize'],
      requestBody: {
        description: 'Consulta Dataprev.',
        required: true,
        content: {
          'application/json': {
            schema: {
              $ref: '#/components/schemas/ObterPropostasRequest',
            },
          },
        },
      },
      responses: {
        '200': {
          description: 'Success.',
          content: {
            'application/json': {
              schema: {
                $ref: '#/components/schemas/ObterPropostasResponse',
              },
            },
          },
        },
        ...commonErrorResponses,
      },
    },
  },

  '/eventos/sonda-obter-propostas': {
    post: {
      summary: 'Confere se site dataprev está disponivel',
      tags: ['Authorize'],
      requestBody: {
        description: 'Consulta Dataprev.',
        required: true,
        content: {
          'application/json': {
            schema: {
              $ref: '#/components/schemas/SondaObterPropostasRequest',
            },
          },
        },
      },
      responses: {
        '200': {
          description: 'Success.',
          content: {
            'application/json': {
              schema: {
                $ref: '#/components/schemas/SondaObterPropostasResponse',
              },
            },
          },
        },
        ...commonErrorResponses,
      },
    },
  },

};
