import { TransacaoDB } from "./db/TransacaoDB";

export type CreateTransacaoDTO = {
  pid: string,
  ext_pf_id: string,
  dt_log: string,
  dt_fim: string,
  ms: string,
  jornada: string,
  info: string,
  sucesso: string,
};

export type GetTransacaoDataprevProposta = {

};

export type GetTransacaoDTO = {
  result: TransacaoDB;
}

export type UpdateTransacaoDTO = {
  pid: string,
  dt_log: string,
  dt_fim: string,
  info: string,
  sucesso: string,
  
};
