import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { CreateTransacaoDTO } from "../TransacaoRepositoryDTOs";

export async function createTransacao(data: CreateTransacaoDTO): Promise<boolean> {
  const db = new OracleDbBase();

  try {
    await db.openConnection();

    const sql = `
  INSERT INTO CCP_TRANSACAO (
  PID,
  EXT_PF_ID,
  DT_LOG,
  DT_FIM,
  MS,
  JORNADA,
  INFO,
  SUCESSO
) VALUES (
  :pid,
  :ext_pf_id,
  :dt_log,
  :dt_fim,
  :ms,
  :jornada,
  :info,
  :sucesso
)
    `;

    await db.callOracle({
      sql,
      binds: {
        pid: data.pid,
        ext_pf_id: data.ext_pf_id,
        dt_log: data.dt_log ? new Date(data.dt_log) : new Date(),
        dt_fim: data.dt_fim ? new Date(data.dt_fim) : null,
        ms: data.ms,
        jornada: data.jornada,
        info: data.info,
        sucesso: data.sucesso
      },
      options: {
        autoCommit: true,
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      },
    });

    return true;

  } catch (error) {
    console.error("Erro ao inserir transação:", error);
    return false;

  } finally {
    await db.closeConnection();
  }
}
