import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { GetTransacaoDataprevProposta, GetTransacaoDTO } from "../TransacaoRepositoryDTOs";

export async function getTransacaoDataprevObterproposta(this: OracleDbBase, data: GetTransacaoDataprevProposta): Promise<GetTransacaoDTO | null> {

  const db = new OracleDbBase();
  
  try {
    await db.openConnection();

    const res = await db.callOracle({
      sql: `
        SELECT 
          ID,
          PID,
          EXT_PF_ID,
          DT_LOG,
          DT_FIM,
          MS,
          JORNADA,
          INFO 
        FROM CCP_TRANSACAO
        WHERE MS = 'DATAPREV'
          AND JORNADA = 'BUSCA_PROPOSTAS'
        ORDER BY DT_LOG DESC
        FETCH FIRST 1 ROWS ONLY
      `,
      binds: {  },
      options: { outFormat: oracledb.OUT_FORMAT_OBJECT },
    });

    if (!res?.result?.rows || res.result.rows.length === 0) {
      return null;
    }

    const [firstRow] = res.result.rows;

    return {
      result: {
        "ID": firstRow.ID,
        "PID": firstRow.PID,
        "EXT_PF_ID": firstRow.EXT_PF_ID,
        "DT_FIM": firstRow.DT_FIM,
        "DT_LOG": firstRow.DT_LOG,        
        "INFO": firstRow.INFO,
        "JORNADA": firstRow.JORNADA,
        "MS": firstRow.MS,
        "SUCESSO": firstRow.SUCESSO,
      } 
    };

  } catch (error) {
    console.error("Erro ao buscar usuário por cpf:", error);
    throw new Error("Falha ao buscar usuário por cpf.");
  } finally {
    await db.closeConnection();
  }
}
