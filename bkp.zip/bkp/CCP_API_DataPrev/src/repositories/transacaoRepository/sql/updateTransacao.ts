import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { UpdateTransacaoDTO } from "../TransacaoRepositoryDTOs";

export async function updateTransacao(data: UpdateTransacaoDTO): Promise<boolean> {
  const db = new OracleDbBase();

  try {
    
    await db.openConnection();

    const sql = `UPDATE CCP_TRANSACAO SET DT_LOG = :dt_log, DT_FIM = :dt_fim, INFO = :info, SUCESSO = :sucesso WHERE PID = :pid`;

    const result = await db.callOracle({
      sql,
      binds: {
        pid: data.pid,
        dt_log: data.dt_log != null ? new Date(data.dt_log) : null,
        dt_fim: data.dt_fim != null ? new Date(data.dt_fim) : null,
        info: data.info,
        sucesso: data.sucesso,
      },
      options: {
        autoCommit: true,
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      },
    });

    if (result?.result?.rowsAffected === 0)
      return false;
    
    return true;

  } catch (error) {
    console.error("Erro ao atualizar transação :", error);
    return false;
  } finally {
    await db.closeConnection();
  }
}
