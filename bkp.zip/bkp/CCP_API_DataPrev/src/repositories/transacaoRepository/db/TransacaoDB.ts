
export type TransacaoDB = {
  "ID": number,
  "PID": string,  
  "EXT_PF_ID": number,
  "DT_LOG": string,
  "DT_FIM": string,
  "MS": string,
  "JORNADA": string,
  "INFO": string,
  "SUCESSO": string
};

