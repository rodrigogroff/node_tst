import "dotenv/config";
import { ITransacaoRepository } from "./ITransacaoRepository";
import { OracleDbBase } from "../../config/OracleDbBase";
import { createTransacao } from "./sql/createTransacao";
import { updateTransacao } from "./sql/updateTransacao";
import { getTransacaoDataprevObterproposta } from "./sql/getTransacaoDataprevObterproposta";

export class OracleTransacaoRepository extends OracleDbBase implements ITransacaoRepository {

  private static instance: ITransacaoRepository | null = null;

  private constructor() {
    super();
  }

  public static getInstance(database?: string): ITransacaoRepository {
    if (!OracleTransacaoRepository.instance) {
      OracleTransacaoRepository.instance = new OracleTransacaoRepository();
    }
    return OracleTransacaoRepository.instance;
  }

  public createTransacao = createTransacao;
  public updateTransacao = updateTransacao;
  public getTransacaoDataprevObterproposta = getTransacaoDataprevObterproposta;
}
