
import {
  CreateTransacaoDTO,
  GetTransacaoDTO, GetTransacaoDataprevProposta,
  UpdateTransacaoDTO
} 
from './TransacaoRepositoryDTOs';

export interface ITransacaoRepository {
  createTransacao(data: CreateTransacaoDTO): Promise<boolean>
  updateTransacao(data: UpdateTransacaoDTO): Promise<boolean>
  getTransacaoDataprevObterproposta(data: GetTransacaoDataprevProposta): Promise<GetTransacaoDTO>
}
