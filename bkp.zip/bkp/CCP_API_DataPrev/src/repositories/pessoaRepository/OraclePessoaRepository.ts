import "dotenv/config";
import { IPessoaRepository } from "./IPessoaRepository";
import { OracleDbBase } from "../../config/OracleDbBase";
import { createPessoa } from "./sql/createPessoa";
import { createPessoaCTPS } from "./sql/createPessoaCTPS";
import { getPessoaByCpf } from "./sql/getPessoaByCpf";
import { createPessoaProposta } from "./sql/createPessoaProposta";
import { getPessoaProposta } from "./sql/getPessoaProposta";
import { getPessoaPropostasByCPFS } from "./sql/getPessoaPropostasByCPFS";
import { getPessoaCTPSVEByCPFS } from "./sql/getPessoaCTPSVEByCPFS";

export class OraclePessoaRepository extends OracleDbBase implements IPessoaRepository {

  private static instance: IPessoaRepository | null = null;

  private constructor() {
    super();
  }

  public static getInstance(database?: string): IPessoaRepository {
    if (!OraclePessoaRepository.instance) {
      OraclePessoaRepository.instance = new OraclePessoaRepository();
    }
    return OraclePessoaRepository.instance;
  }
  
  public createPessoa = createPessoa;  
  public createPessoaCTPS = createPessoaCTPS;
  public getPessoaByCpf = getPessoaByCpf;
  public createPessoaProposta = createPessoaProposta;
  public getPessoaProposta = getPessoaProposta;
  public getPessoaPropostasByCPFS = getPessoaPropostasByCPFS;
  public getPessoaCTPSVEByCPFS = getPessoaCTPSVEByCPFS;
   
}
