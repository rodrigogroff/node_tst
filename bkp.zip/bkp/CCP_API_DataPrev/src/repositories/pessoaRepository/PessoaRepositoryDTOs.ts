import { PessoaFisicaCTPSDB } from "./db/PessoaFisicaCTPSDB";
import { PessoaFisicaDB  } from "./db/PessoaFisicaDB"; 
import { PessoaFisicaPropostaDB } from "./db/PessoaFisicaPropostaDB";

export type CreatePessoaDTO = {
  pid: string;
  ext_pf_id: string;
  email: string;
  nome_completo: string;
  primeiro_nome: string;
  sobre_nome: string;
  nome_pai: string;
  nome_mae: string;
  dt_nascimento: string;
  cpf: string;
  rg: string;
  pis: string;
  pasep: string;
  nit: string;
  nacionalidade: string;
  cidade_natural: string;
  estado_natural: string;
  sexo: string;
  estado_civil: string;
  endereco: string;
  endereco_num: string;
  endereco_compl: string;
  cep: string;
  dt_criacao: string;
  dt_alteracao: string;
};

export type CreatePessoaCPTSDTO = {
  pid: string;
  ext_pf_id: string;
  nome_empresa: string;
  cargo: string;
  cpf: string;
  cnpj: string;
  dt_inicio: string;
  dt_fim: string;
  dt_criacao: string;
  dt_alteracao: string;
  vr_bruto: string;
  vr_liquido: string;
};

export type CreatePessoaPropostaDTO = {
  pid: string;
  cpf: string;
  id_dataprev: string;
  ext_pf_id: string;
  fk_situacao_atual: number;
  valor_solicitado: string;
  parcelas: string;
  dt_criacao: string;
};

export type GetPessoaByCpfDTO = {
  cpf: string;
}

export type GetPessoaResponseDTO = {
  result: PessoaFisicaDB;
};


export type GetPessoaPropostaDTO = {
  pf_id: string;
  valor_solicitado: number;
  parcelas: number;
}


export type GetPessoaPropostaResponseDTO = {
  result: PessoaFisicaPropostaDB;
}

export type GetPessoaPropostaByCPFSDTO = {
  cpfs: string[];  
}

export type GetPessoaPropostaByCPFSResponseDTO = {
  results: PessoaFisicaPropostaDB[];
}

export type GetPessoaCTPSVEByCPFS = {
  cpfs: string[];  
}

export type GetPessoaCTPSVEByCPFSResponseDTO = {
  results: PessoaFisicaCTPSDB[];
}
