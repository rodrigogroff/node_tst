
export type PessoaFisicaPropostaSituacaoDB = {
  "ID": number,
  "NOME": string,
};

