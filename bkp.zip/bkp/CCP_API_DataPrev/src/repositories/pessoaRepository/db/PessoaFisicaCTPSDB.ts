
export type PessoaFisicaCTPSDB = {
  "ID": number,
  "PID": string,
  "EXT_PF_ID": string,
  "NOME_EMPRESA": string,
  "CPF": string,
  "CNPJ": string,
  "CARGO": string,
  "DT_INICIO": string,
  "DT_FIM": string,
  "DT_CRIACAO": string,
  "DT_ALTERACAO": string,
  "VALOR_BRUTO": string,
  "VALOR_LIQUIDO": string,
};
