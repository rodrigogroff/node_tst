
export type PessoaFisicaPropostaDB = {
  "ID": number,
  "PID": string,
  "CPF": string,
  "ID_DATAPREV": string,
  "EXT_PF_ID": string,
  "VALOR_SOLICITADO": number,
  "PARCELAS": number,
  "FK_SITUACAO_ATUAL": string,
  "DT_CRIACAO": string,
};
