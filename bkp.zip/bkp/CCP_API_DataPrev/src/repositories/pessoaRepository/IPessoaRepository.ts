
import { 
  CreatePessoaDTO, CreatePessoaCPTSDTO,
  GetPessoaByCpfDTO, GetPessoaResponseDTO,  
  CreatePessoaPropostaDTO,
  GetPessoaPropostaDTO, GetPessoaPropostaResponseDTO,
  GetPessoaPropostaByCPFSDTO, GetPessoaPropostaByCPFSResponseDTO,
  GetPessoaCTPSVEByCPFS,
  GetPessoaCTPSVEByCPFSResponseDTO

} from './PessoaRepositoryDTOs';

export interface IPessoaRepository {
  createPessoa(data: CreatePessoaDTO): Promise<boolean>;
  createPessoaProposta(data: CreatePessoaPropostaDTO): Promise<boolean>;
  createPessoaCTPS(data: CreatePessoaCPTSDTO): Promise<boolean>;  
  getPessoaByCpf(data: GetPessoaByCpfDTO): Promise<GetPessoaResponseDTO>;  
  getPessoaProposta(data: GetPessoaPropostaDTO): Promise<GetPessoaPropostaResponseDTO>;
  getPessoaPropostasByCPFS(data: GetPessoaPropostaByCPFSDTO): Promise<GetPessoaPropostaByCPFSResponseDTO>;
  getPessoaCTPSVEByCPFS(data: GetPessoaCTPSVEByCPFS): Promise<GetPessoaCTPSVEByCPFSResponseDTO>;
}
