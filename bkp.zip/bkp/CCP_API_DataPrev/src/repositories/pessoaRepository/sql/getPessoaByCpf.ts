import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { GetPessoaByCpfDTO, GetPessoaResponseDTO } from "../PessoaRepositoryDTOs";

export async function getPessoaByCpf(this: OracleDbBase, data: GetPessoaByCpfDTO): Promise<GetPessoaResponseDTO | null> {

  const db = new OracleDbBase();
  
  try {
    await db.openConnection();

    const res = await db.callOracle({
      sql: `
      SELECT 
          ID,
          PID,
          EXT_PF_ID,
          EMAIL,
          NOME_COMPLETO,
          PRIMEIRO_NOME,
          SOBRE_NOME,
          NOME_PAI,
          NOME_MAE,
          DT_NASCIMENTO,
          CPF,
          RG,
          PIS,
          PASEP,
          NIT,
          NACIONALIDADE,
          CIDADE_NATURAL,
          ESTADO_NATURAL,
          SEXO,
          ESTADO_CIVIL,
          ENDERECO,
          ENDERECO_NUM,
          ENDERECO_COMPL,
          CEP,
          DT_CRIACAO,
          DT_ALTERACAO
        FROM CCP_PESSOAFISICA
        WHERE CPF = :cpf
        FETCH FIRST 1 ROWS ONLY
      `,
      binds: { cpf: data.cpf },
      options: { outFormat: oracledb.OUT_FORMAT_OBJECT },
    });

    if (!res?.result?.rows || res.result.rows.length === 0) {
      return null;
    }

    const [firstRow] = res.result.rows;

    return {
      result: {
        "ID": firstRow.ID,
        "PID": firstRow.PID,
        "EXT_PF_ID": firstRow.EXT_PF_ID,
        "EMAIL": firstRow.EMAIL,
        "NOME_COMPLETO": firstRow.NOME_COMPLETO,
        "PRIMEIRO_NOME": firstRow.PRIMEIRO_NOME,
        "SOBRE_NOME": firstRow.SOBRE_NOME,
        "NOME_PAI": firstRow.NOME_PAI,
        "NOME_MAE": firstRow.NOME_MAE,
        "DT_NASCIMENTO": firstRow.DT_NASCIMENTO,
        "CPF": firstRow.CPF,
        "RG": firstRow.RG,
        "PIS": firstRow.PIS,
        "PASEP": firstRow.PASEP,
        "NIT": firstRow.NIT,
        "NACIONALIDADE": firstRow.NACIONALIDADE,
        "CIDADE_NATURAL": firstRow.CIDADE_NATURAL,
        "ESTADO_NATURAL": firstRow.ESTADO_NATURAL,
        "SEXO": firstRow.SEXO,
        "ESTADO_CIVIL": firstRow.ESTADO_CIVIL,
        "ENDERECO": firstRow.ENDERECO,
        "ENDERECO_NUM": firstRow.ENDERECO_NUM,
        "ENDERECO_COMPL": firstRow.ENDERECO_COMPL,
        "CEP": firstRow.CEP,
        "DT_CRIACAO": firstRow.DT_CRIACAO,
        "DT_ALTERACAO": firstRow.DT_ALTERACAO,
      }
    };    

  } catch (error) {
    console.error("Erro ao buscar usuário por cpf:", error);
    throw new Error("Falha ao buscar usuário por cpf.");
  } finally {
    await db.closeConnection();
  }
}
