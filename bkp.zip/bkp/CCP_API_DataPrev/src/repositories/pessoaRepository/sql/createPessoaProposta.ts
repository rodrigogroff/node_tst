import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { CreatePessoaPropostaDTO } from "../PessoaRepositoryDTOs";

export async function createPessoaProposta(data: CreatePessoaPropostaDTO): Promise<boolean> {
  const db = new OracleDbBase();

  try {
    await db.openConnection();

    const sql = `
      INSERT INTO CCP_PESSOAFISICA_PROPOSTA (
        PID,
        CPF,
        ID_DATAPREV,        
        EXT_PF_ID,
        FK_SITUACAO_ATUAL,
        VALOR_SOLICITADO,
        PARCELAS,
        DT_CRIACAO    
      ) VALUES (
        :pid,
        :cpf,
        :id_dataprev,
        :ext_pf_id,
        :fk_situacao_atual,
        :valor_solicitado,
        :parcelas,
        :dt_criacao
      )
    `;

    await db.callOracle({
      sql,
      binds: {        
        pid: data.pid,
        cpf: data.cpf,
        id_dataprev: data.id_dataprev,
        ext_pf_id: data.ext_pf_id,
        fk_situacao_atual: data.fk_situacao_atual,
        valor_solicitado: data.valor_solicitado,
        parcelas: data.parcelas,
        dt_criacao: new Date(data.dt_criacao),        
      },
      options: {
        autoCommit: true,
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      },
    });

    return true;
  } catch (error) {
    
    throw({error: "Falha no create pessoa proposta: " + error })

  } finally {
    await db.closeConnection();
  }
}
