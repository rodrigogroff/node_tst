import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { GetPessoaPropostaDTO, GetPessoaPropostaResponseDTO } from "../PessoaRepositoryDTOs";

export async function getPessoaProposta(this: OracleDbBase, data: GetPessoaPropostaDTO): Promise<GetPessoaPropostaResponseDTO | null> {

  const db = new OracleDbBase();
  
  try {
    
    await db.openConnection();

    const res = await db.callOracle({
      sql: `
      SELECT 
        ID,
        PID, 
        CPF,
        ID_DATAPREV,
        EXT_PF_ID,
        FK_SITUACAO_ATUAL,
        VALOR_SOLICITADO,
        PARCELAS,
        DT_CRIACAO 
      FROM CCP_PESSOAFISICA_PROPOSTA
        WHERE 
          EXT_PF_ID = :pf_id and 
          VALOR_SOLICITADO = :valor_solicitado and 
          PARCELAS = :parcelas 
        FETCH FIRST 1 ROWS ONLY
      `,
      binds: { 
        pf_id: data.pf_id, 
        valor_solicitado: data.valor_solicitado,
        parcelas: data.parcelas
      },
      options: { outFormat: oracledb.OUT_FORMAT_OBJECT },
    });

    if (!res?.result?.rows || res.result.rows.length === 0) {
      return null;
    }

    const [firstRow] = res.result.rows;

    return {
      result: {
        "ID": firstRow.ID,
        "CPF": firstRow.CPF,
        "PID": firstRow.PID,
        "ID_DATAPREV": firstRow.ID_DATAPREV,
        "EXT_PF_ID": firstRow.EXT_PF_ID,
        "VALOR_SOLICITADO": firstRow.VALOR_SOLICITADO,
        "PARCELAS": firstRow.PARCELAS,
        "FK_SITUACAO_ATUAL": firstRow.FK_SITUACAO_ATUAL,
        "DT_CRIACAO": firstRow.DT_CRIACAO,
      }
    };    

  } catch (error) {
    console.error("Erro ao buscar usuário por cpf:", error);
    throw new Error("Falha ao buscar usuário por cpf.");
  } finally {
    await db.closeConnection();
  }
}
