import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { CreatePessoaCPTSDTO } from "../PessoaRepositoryDTOs";

export async function createPessoaCTPS(data: CreatePessoaCPTSDTO): Promise<boolean> {
  const db = new OracleDbBase();

  try {
    await db.openConnection();

    const sql = `
      INSERT INTO CCP_PESSOAFISICA_CTPS_VE (        
        PID,
        CPF, 
        CNPJ,
        EXT_PF_ID,
        NOME_EMPRESA,
        CARGO, 
        DT_INICIO,
        DT_FIM,   
        DT_CRIACAO,
        DT_ALTERACAO,
        VALOR_BRUTO,
        VALOR_LIQUIDO       
      ) VALUES (
        :pid,
        :cpf,
        :cnpj,
        :ext_pf_id,
        :nome_empresa,
        :cargo,
        :dt_inicio,
        :dt_fim,
        :dt_criacao,
        :dt_alteracao,
        :vr_bruto,
        :vr_liquido
      )
    `;

    await db.callOracle({
      sql,
      binds: {
        pid: data.pid,
        cpf: data.cpf,
        cnpj: data.cnpj,
        ext_pf_id: data.ext_pf_id,
        nome_empresa: data.nome_empresa,
        cargo: data.cargo,
        dt_inicio: new Date(data.dt_inicio),
        dt_fim: data.dt_fim ? new Date(data.dt_fim) : null,
        dt_criacao: new Date(data.dt_criacao),
        dt_alteracao: data.dt_alteracao ? new Date(data.dt_alteracao) : null,
        vr_bruto: data.vr_bruto,
        vr_liquido: data.vr_liquido,
      },
      options: {
        autoCommit: true,
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      },
    });

    return true;

  } catch (error) {
    
    throw({error: "Falha no create pessoa ctps: " + error })

  } finally {
    await db.closeConnection();
  }
}
