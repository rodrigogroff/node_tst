import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { GetPessoaPropostaByCPFSDTO, GetPessoaPropostaByCPFSResponseDTO } from "../PessoaRepositoryDTOs";
import { PessoaFisicaPropostaDB } from '../db/PessoaFisicaPropostaDB';

export async function getPessoaPropostasByCPFS(
  this: OracleDbBase,
  data: GetPessoaPropostaByCPFSDTO
): Promise<GetPessoaPropostaByCPFSResponseDTO | null> {

  const db = new OracleDbBase();

  try {
    await db.openConnection();

    const cpfs = data.cpfs;

    if (!cpfs || cpfs.length === 0) {
      return null;
    }

    // ---- divide os CPFs em blocos de até 1000 ----
    const chunkSize = 1000;
    const chunks: string[][] = [];
    for (let i = 0; i < cpfs.length; i += chunkSize) {
      chunks.push(cpfs.slice(i, i + chunkSize));
    }

    // ---- montar SQL e binds ----
    const sqlParts: string[] = [];
    const bindParams: any = {};

    chunks.forEach((chunk, chunkIndex) => {
      const bindNames = chunk.map((_, i) => `:cpf_${chunkIndex}_${i}`).join(',');

      chunk.forEach((cpf, i) => {
        bindParams[`cpf_${chunkIndex}_${i}`] = cpf;
      });

      sqlParts.push(`
        SELECT 
          ID,
          CPF,
          PID,
          ID_DATAPREV,
          EXT_PF_ID,
          FK_SITUACAO_ATUAL,
          VALOR_SOLICITADO,
          PARCELAS,
          DT_CRIACAO
        FROM CCP_PESSOAFISICA_PROPOSTA
        WHERE TRIM(CPF) IN (${bindNames})
      `);
    });

    const finalSQL = sqlParts.join(" UNION ALL ");

    const res = await db.callOracle({
      sql: finalSQL,
      binds: bindParams,
      options: { outFormat: oracledb.OUT_FORMAT_OBJECT },
    });

    if (!res?.result?.rows || res.result.rows.length === 0) {
      return null;
    }

    const rows = res.result.rows;

    const results: PessoaFisicaPropostaDB[] = rows.map(row => ({
      ID: row.ID,
      CPF: row.CPF,
      PID: row.PID,
      ID_DATAPREV: row.ID_DATAPREV,
      EXT_PF_ID: row.EXT_PF_ID,
      FK_SITUACAO_ATUAL: row.FK_SITUACAO_ATUAL,
      VALOR_SOLICITADO: row.VALOR_SOLICITADO,
      PARCELAS: row.PARCELAS,
      DT_CRIACAO: row.DT_CRIACAO,
    }));

    return { results };

  } catch (error) {
    console.log("Erro ao buscar propostas por cpf:", error);
  } finally {
    await db.closeConnection();
  }
}
