import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { GetPessoaCTPSVEByCPFS, GetPessoaCTPSVEByCPFSResponseDTO } from "../PessoaRepositoryDTOs";
import { PessoaFisicaCTPSDB } from '../db/PessoaFisicaCTPSDB';

export async function getPessoaCTPSVEByCPFS(
  this: OracleDbBase,
  data: GetPessoaCTPSVEByCPFS
): Promise<GetPessoaCTPSVEByCPFSResponseDTO | null> {

  const db = new OracleDbBase();

  try {

    await db.openConnection();

    const cpfs = data.cpfs;

    if (!cpfs || cpfs.length === 0) {
      return null;
    }

    // ---- divide em blocos de até 1000 ----
    const chunkSize = 1000;
    const chunks: string[][] = [];

    for (let i = 0; i < cpfs.length; i += chunkSize) {
      chunks.push(cpfs.slice(i, i + chunkSize));
    }

    // ---- monta SQL (UNION ALL) + binds ----
    const sqlParts: string[] = [];
    const bindParams: any = {};

    chunks.forEach((chunk, chunkIndex) => {
      const bindNames = chunk.map((_, i) => `:cpf_${chunkIndex}_${i}`).join(',');

      chunk.forEach((cpf, i) => {
        bindParams[`cpf_${chunkIndex}_${i}`] = cpf;
      });

      sqlParts.push(`
        SELECT 
          ID,
          PID,
          EXT_PF_ID,
          NOME_EMPRESA, 
          CPF,
          CNPJ,
          CARGO,
          DT_INICIO, 
          DT_FIM,
          DT_CRIACAO,
          DT_ALTERACAO,
          VALOR_BRUTO,
          VALOR_LIQUIDO 
        FROM CCP_PESSOAFISICA_CTPS_VE
        WHERE TRIM(CPF) IN (${bindNames})
      `);
    });

    const finalSQL = sqlParts.join(" UNION ALL ");

    const res = await db.callOracle({
      sql: finalSQL,
      binds: bindParams,
      options: { outFormat: oracledb.OUT_FORMAT_OBJECT }
    });

    if (!res?.result?.rows || res.result.rows.length === 0) {
      return null;
    }

    const rows = res.result.rows;

    const results: PessoaFisicaCTPSDB[] = rows.map(row => ({
      ID: row.ID,
      PID: row.PID,
      EXT_PF_ID: row.EXT_PF_ID,
      NOME_EMPRESA: row.NOME_EMPRESA,
      CPF: row.CPF,
      CNPJ: row.CNPJ,
      CARGO: row.CARGO,
      DT_INICIO: row.DT_INICIO,
      DT_FIM: row.DT_FIM,
      DT_CRIACAO: row.DT_CRIACAO,
      DT_ALTERACAO: row.DT_ALTERACAO,
      VALOR_BRUTO: row.VALOR_BRUTO,
      VALOR_LIQUIDO: row.VALOR_LIQUIDO 
    }));

    return { results };

  } catch (error) {
    console.log("Erro ao buscar CTPS/VE por cpf:", error);
  } finally {
    await db.closeConnection();
  }
}
