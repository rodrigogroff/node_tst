import oracledb from 'oracledb';
import { OracleDbBase } from "../../../config/OracleDbBase";
import { CreatePessoaDTO } from "../PessoaRepositoryDTOs";

export async function createPessoa(data: CreatePessoaDTO): Promise<boolean> {
  const db = new OracleDbBase();

  try {

    await db.openConnection();

    const sql = `
      INSERT INTO CCP_PESSOAFISICA (
        PID,
        EXT_PF_ID,
        EMAIL,
        NOME_COMPLETO,
        PRIMEIRO_NOME,
        SOBRE_NOME,
        NOME_PAI,
        NOME_MAE,
        DT_NASCIMENTO,
        CPF,
        RG,
        PIS,
        PASEP,
        NIT,
        NACIONALIDADE,
        CIDADE_NATURAL,
        ESTADO_NATURAL,
        SEXO,
        ESTADO_CIVIL,
        ENDERECO,
        ENDERECO_NUM,
        ENDERECO_COMPL,
        CEP,
        DT_CRIACAO,
        DT_ALTERACAO
      ) VALUES (
        :pid,
        :ext_pf_id,
        :email,
        :nome_completo,
        :primeiro_nome,
        :sobre_nome,
        :nome_pai,
        :nome_mae,
        :dt_nascimento,
        :cpf,
        :rg,
        :pis,
        :pasep,
        :nit,
        :nacionalidade,
        :cidade_natural,
        :estado_natural,
        :sexo,
        :estado_civil,
        :endereco,
        :endereco_num,
        :endereco_compl,
        :cep,
        :dt_criacao,
        :dt_alteracao
      )
    `;

    await db.callOracle({
      sql,
      binds: {
        pid: data.pid,
        ext_pf_id: data.ext_pf_id,
        email: data.email,
        nome_completo: data.nome_completo,
        primeiro_nome: data.primeiro_nome,
        sobre_nome: data.sobre_nome,
        nome_pai: data.nome_pai,
        nome_mae: data.nome_mae,
        dt_nascimento: new Date(data.dt_nascimento),
        cpf: data.cpf,
        rg: data.rg,
        pis: data.pis,
        pasep: data.pasep,
        nit: data.nit,
        nacionalidade: data.nacionalidade,
        cidade_natural: data.cidade_natural,
        estado_natural: data.estado_natural,
        sexo: data.sexo,
        estado_civil: data.estado_civil,
        endereco: data.endereco,
        endereco_num: data.endereco_num,
        endereco_compl: data.endereco_compl,
        cep: data.cep,
        dt_criacao: new Date(data.dt_criacao),
        dt_alteracao: data.dt_alteracao ? new Date(data.dt_alteracao) : null
      },
      options: {
        autoCommit: true,
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      },
    });

    return true;
  } catch (error) {

    throw({error: "Falha no create pessoa: " + error })
    
  } finally {
    await db.closeConnection();
  }
}
