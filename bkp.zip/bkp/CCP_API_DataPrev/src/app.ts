import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import init from './bootstrap';
import * as TpzErr from 'tpz-errors';
import { loggerMiddleware } from 'tpz-logger';
import addProjectHeader from './middlewares/addProjectHeader';
import { PROJECT_NAME } from './constants/project';
import swaggerUi from 'swagger-ui-express';
import swaggerSpec = require('./config/swagger');
import fs from 'fs';

import { routes } from './routes';

const app = express();
init();

const swaggerOptions = {
  customCss: `.models { display: none !important;} 
              table.live-responses-table td.response-col_description > div:last-child {display: none !important; }
              #auth-bearer-value { width: 100% }`,
};

app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(addProjectHeader(PROJECT_NAME));
app.use(loggerMiddleware);

app.use('/swagger', swaggerUi.serve, swaggerUi.setup(swaggerSpec, swaggerOptions));

app.use(routes);
app.all('*', TpzErr.errorNotFound);
app.use(TpzErr.errorHandlerMW);

export { app };
