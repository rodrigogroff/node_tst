import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

const addProjecInHeaderMiddleware = (project: string) => {
  return (request: Request, response: Response, next: NextFunction) => {
    const projectTrace = request.headers['projects-trace'] as string | undefined;

    const updatedTrace = projectTrace
      ? `${projectTrace}; Project: ${project}`
      : `Request unique identifier: ${uuidv4()}; Project: ${project};`;

    response.setHeader('projects-trace', updatedTrace);

    next();
  };
};

export default addProjecInHeaderMiddleware;
