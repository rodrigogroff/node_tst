// utils/validators.ts

/**
 * Checks if an email address has valid syntax.
 */
export function checkEmailSyntax(email: string | null | undefined): boolean {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validates a Brazilian CPF number.
 */
export function checkCPF(cpf: string): boolean {
  // Remove non-numeric characters
  const cleanCpf = cpf.replace(/[^\d]+/g, '');

  // Must be 11 digits
  if (cleanCpf.length !== 11) return false;

  // Invalid if all digits are the same
  if (/^(\d)\1+$/.test(cleanCpf)) return false;

  // Validate first check digit
  let soma = 0;
  for (let i = 1; i <= 9; i++) {
    soma += parseInt(cleanCpf.substring(i - 1, i)) * (11 - i);
  }
  let resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;
  if (resto !== parseInt(cleanCpf.substring(9, 10))) return false;

  // Validate second check digit
  soma = 0;
  for (let i = 1; i <= 10; i++) {
    soma += parseInt(cleanCpf.substring(i - 1, i)) * (12 - i);
  }
  resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;
  if (resto !== parseInt(cleanCpf.substring(10, 11))) return false;

  return true;
}

/**
 * Validates if a full name has at least two valid parts.
 */
export function checkFullName(name: string | null | undefined): boolean {
  if (!name || typeof name !== 'string') return false;

  const parts = name.trim().split(/\s+/);

  // Must contain at least first and last name
  if (parts.length < 2) return false;

  // Each part should have at least 2 letters
  if (parts.some(part => part.length < 2)) return false;

  // Validate allowed characters (letters, accents, apostrophes, hyphens)
  const nameRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ'’-]+$/;
  return parts.every(part => nameRegex.test(part));
}
