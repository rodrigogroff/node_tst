import { config } from 'dotenv';

const init = () => {
  if (process.env.NODE_ENV !== 'production') {
    config({
      path: '.env',
    });
  }
};

export default init;
