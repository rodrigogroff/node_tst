/* eslint-disable @typescript-eslint/no-explicit-any */
import { logger as tpzLogger } from 'tpz-logger';
import { PROJECT_NAME } from '../constants/project';

export const logger = {
  info: (message: string) => {
    tpzLogger.info(`${PROJECT_NAME} - ${message}`);
  },
  debug: (message: string) => {
    tpzLogger.debug(`${PROJECT_NAME} - ${message}`);
  },
  warn: (message: string, error) => {
    tpzLogger.warn(`${PROJECT_NAME} - ${message}`, error);
  },
  error: (message: string, error) => {
    tpzLogger.error(`${PROJECT_NAME} - ${message}`, error);
  },
};
