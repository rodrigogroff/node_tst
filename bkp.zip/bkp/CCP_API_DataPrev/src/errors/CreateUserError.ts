import { CustomError } from 'tpz-errors';

export class CreateUserError extends CustomError {
  constructor() {
    super('Create user error');
    this.status = 500;
  }
}
