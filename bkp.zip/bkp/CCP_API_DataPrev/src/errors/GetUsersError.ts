import { CustomError } from 'tpz-errors';

export class GetUsersError extends CustomError {
  constructor() {
    super('Please inform a matching pattern');
    this.status = 400;
  }
}
