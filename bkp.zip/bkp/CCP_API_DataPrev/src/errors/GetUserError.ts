import { CustomError } from 'tpz-errors';

export class GetUserError extends CustomError {
  constructor() {
    super('Please inform a valid id');
    this.status = 400;
  }
}
