/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-function-type */
import queueModule from 'tpz-queue';
import { logger } from '../../../bootstrap/logger';
import { IQueueProvider } from '../interfaces/IQueueProvider';

export class RabbitMqManagerProvider implements IQueueProvider {
  private static instance: IQueueProvider | null = null;
  private initialized: boolean;
  private queue: any;

  constructor() {}

  public static getInstance(): IQueueProvider {
    if (!RabbitMqManagerProvider.instance) {
      RabbitMqManagerProvider.instance = new RabbitMqManagerProvider();
    }
    return RabbitMqManagerProvider.instance;
  }

  public async initializeQueue(
    queueName: string,
    consumer: Function,
    retryIntervals: number[],
  ): Promise<void> {
    if (this.initialized) {
      logger.info('Queue already initialized.');
      return;
    }

    try {
      this.queue = queueModule[queueName].consume(consumer).retry(retryIntervals);
      const channel = await this.queue.getChannel();
      channel.on('connectionError', (err) => {
        logger.error('Connection error over RabbitMQ', err);
        process.exit();
      });
      this.initialized = true;
      logger.info(`Rabbit MQ connected successfully for queue ${queueName}`);
    } catch (e) {
      logger.error('ERROR', e);
      throw e;
    }
  }

  public getQueue(): any {
    if (!this.initialized) {
      throw new Error('Queue not initialized.');
    }
    return this.queue;
  }

  public async sendMessage(data: any): Promise<void> {
    try {
      const queue = this.getQueue();
      await queue.sendToQueue(data);
      logger.info('Message sent successfully');
    } catch (error) {
      logger.error(`Failed to send message`, error);
      throw error;
    }
  }
}
