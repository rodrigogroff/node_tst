/* eslint-disable @typescript-eslint/no-explicit-any */
export interface IQueueProvider {
  initializeQueue(name: string, consumer: any, retryIntervals: number[]): Promise<void>;
  sendMessage(data: any): Promise<void>;
  getQueue(): any;
}
