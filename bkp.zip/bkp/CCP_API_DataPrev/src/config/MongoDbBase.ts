export class MongoDbBase {

  protected database = '';
  protected collection = '';

  constructor(database: string, collection: string) {
    if (database.trim().length <= 0 || collection.trim().length <= 0) {
      throw new Error('Please, check your mongo connection variables.');
    }
    this.database = database
    this.collection = collection;
  }
}
