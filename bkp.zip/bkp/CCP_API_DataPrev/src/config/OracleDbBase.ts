import oracledb from "oracledb";
import { logger } from "../bootstrap/logger";

export class OracleDbBase {

  // não faz mais nada aqui
  async openConnection(): Promise<void> {
    return;
  }

  async callOracle(object: any): Promise<any> {
    let connection: oracledb.Connection | null = null;

    try {
      const pool = oracledb.getPool("mainPool");
      connection = await pool.getConnection();

      object.result = await connection.execute(
        object.sql,
        object.binds,
        object.options
      );

      await connection.commit();
      return object;

    } catch (error) {
      logger.error("Erro on calling oracle", error);
      if (connection) {
        try { await connection.rollback(); } catch {}
      }
      return null;
    } finally {
      if (connection) {
        try { await connection.close(); } catch {}
      }
    }
  }

  async validateQueryRows(obj: any): Promise<any> {
    if (obj?.result?.rows !== undefined) {
      return obj;
    }
    throw new Error("Result incorrect: rows not found.");
  }

  async validateFunctionParams(obj: any): Promise<any> {
    if (!obj.sql) {
      throw Error("SQL param is not defined.");
    }

    if (!obj.binds) obj.binds = [];
    if (!obj.options) obj.options = { outFormat: oracledb.OUT_FORMAT_OBJECT };

    return obj;
  }

  async closeConnection(): Promise<void> {
    // método mantido apenas para compatibilidade
    // não deve fechar pool ou conexão
  }

  async executeQuery(sql: any, binds: any, options: any = null): Promise<any> {
    let object = { sql, binds, options };

    try {
      object = await this.validateFunctionParams(object);
      const dbResult = await this.callOracle(object);

      await this.validateQueryRows(dbResult);
      return dbResult.result.rows;

    } catch (error) {
      logger.error("error: ", error);
      return null;
    }
  }
}
