import swaggerJsdoc from 'swagger-jsdoc';
import { zodSchemas } from '../docs/zod-registry';
import { authPaths } from '../docs/authorize-doc';
import { eventosPaths } from '../docs/eventos-doc';

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CCP API DATAPREV',
      version: '1.0.0',
    },
    servers: [{ url: 'http://localhost:3010' }],

    paths: {
      ...authPaths,
      ...eventosPaths,
    },

    components: {
      schemas: {
        ...zodSchemas,
        ErrorResponse: {
          type: 'object',
          properties: {
            statusCode: { type: 'number', example: 400 },
            message: { type: 'string', example: 'Requisição inválida' },
          },
        },
      },
      responses: {
        BadRequest: {
          description: 'Bad Request.',
        },
        Unauthorized: {
          description: 'Invalid Token.',
        },
        Forbidden: {
          description: 'Forbidden.',
        },
        NotFound: {
          description: 'Not Found.',
        },
        MethodNotAllowed: {
          description: 'Method Not Allowed.',
        },
        InternalServerError: {
          description: 'Internal Server Error.',
        },
        NotImplemented: {
          description: 'Not Implemented.',
        },
        BadGateway: {
          description: 'Bad Gateway.',
        },
        ServiceUnavailable: {
          description: 'Service Unavailable.',
        },
      },
      securitySchemes: {
        'Token de Acesso (JWT)': {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description:
            'Insira seu token de acesso (JWT) para autorizar as requisições. Você pode obter um token na rota /auth.',
        },
      },
    },
    security: [{ bearerAuth: [] }],
  },
  apis: [],
};

const swaggerSpec = swaggerJsdoc(options);
export = swaggerSpec;
