import { JwtPayload } from 'jsonwebtoken';
declare global {
  namespace Express {
    export interface CustomJwtPayload extends JwtPayload {
      userId: string;
      email: string;
    }

    export interface Request {
      user: CustomJwtPayload;
    }
  }
}
