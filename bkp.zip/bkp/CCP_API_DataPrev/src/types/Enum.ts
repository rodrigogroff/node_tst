/* eslint-disable no-unused-vars */
export enum EventsEnum {
  createUser = 'createUser',
}
