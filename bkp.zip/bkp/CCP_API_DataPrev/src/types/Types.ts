export type Pagination = {
  page?: number;
  limit: number;
};

export type PaginationResponse<T> = {
  nextPage: boolean;
  perPage: number;
  pageData: Array<T>;
  lastPage?: number;
};
