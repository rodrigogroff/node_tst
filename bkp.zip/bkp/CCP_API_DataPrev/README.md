
# 🧩 API DataPrev — Integração de Consignado e Vínculos Trabalhistas

A API **DataPrev** fornece serviços de integração entre instituições financeiras e a base de dados do INSS.  
Ela permite a **consulta de vínculos trabalhistas**, **gestão de autorizações** e **operações de crédito consignado** de forma automatizada e segura.

---

## 🚦 Rotas Principais

| Recurso | Dominio | Descrição | Qtd Endpoints |
|----------|------------|---------------|---------------|
| `eventos` | Topazio | Disparar eventos | 1 |
| `propostas-ctps` | DataPrev | Propostas CTPS (Cadastro de Trabalho Digital) | 3 |
| `trabalhadores` | DataPrev | Autorizações e dados de trabalhadores | 4 |
| `emprestimos` | DataPrev | Empréstimos consignados e repasses | 6 |

---

## 📁 Endpoints

### `eventos`
| Método | Dominio | Endpoint | Descrição | Gatilho | Observação |
|---------|-----------|-----------|------------|------------|------------|
| GET | Topazio | `/eventos/obter-propostas` | Consulta de propostas válidas na DataPrev | Scheduler? (1 min) |

### `propostas-ctps`
| Método | Dominio | Endpoint | Descrição | Gatilho | Observação |
|---------|-----------|-----------|------------|------------|------------|
| GET | DataPrev | `/propostas-ctps/solicitacoes-trabalhador-paginado` | Consulta de propostas válidas (paginado) | Scheduler (1 min) | Consultar e guardar todas as páginas em banco
| GET | DataPrev | `/propostas-ctps/solicitacoes-trabalhador` | Consulta de propostas válidas | (* não usar) | usar paginador e pegar tudo
| POST | DataPrev | `/propostas-ctps/inclusao` | Realização da proposta | Consumo de fila posterior | Consumir a fila após descartar propostas ruins

---

### `trabalhadores`
| Método | Dominio | Endpoint | Descrição |
|---------|-----------|-----------|------------|
| POST | DataPrev | `/trabalhadores/autorizar-consulta-dados-trabalhador` | Autoriza acesso aos dados do trabalhador |
| GET | DataPrev | `/trabalhadores/listar-autorizados-trabalhador` | Lista vínculos autorizados |
| GET | DataPrev | `/trabalhadores/consultar-dados-trabalhador` | Consulta vínculo ativo |
| GET | DataPrev | `/trabalhadores/consultar-vinculos-novos-trabalhador` | Consulta novos vínculos |

---

### `emprestimos`
| Método | Dominio | Endpoint | Descrição |
|---------|-----------|-----------|------------|
| POST | DataPrev | `/emprestimos/averbar-consignado-trabalhador` | Averbação do empréstimo |
| POST | DataPrev | `/emprestimos/incluir-informacoes-contrato-trabalhador` | Inclusão das informações do contrato |
| GET | DataPrev | `/emprestimos/consultar-repasse-pagamentos` | Consulta repasses efetuados pela CEF |
| GET | DataPrev | `/emprestimos/consultar-escrituracoes-remuneracoes` | Consulta descontos escriturados no eSocial |
| GET | DataPrev | `/emprestimos/consultar-emprestimo-encerrado-termino-vinculo` | Consulta empréstimos encerrados por término de vínculo |
| POST | DataPrev | `/emprestimos/renegociar-consignado-trabalhador` | Renegociação de contratos encerrados |

---

### `links`

https://docs.dataprev.gov.br/docs/credito-trabalhador/fluxos-servicos-e-portais-disponiveis/ 

https://lucid.app/lucidchart/a8703218-829c-4c5b-9bfa-caf98a7180da/edit?viewport_loc=4855%2C3161%2C5415%2C1942%2C0_0&invitationId=inv_9ab15c4b-1fa2-4672-a61b-f062614f3942 

https://store.dataprev.gov.br/devportal/apis 

https://docs.dataprev.gov.br/docs/credito-trabalhador/ 

Manual de Comunicação – 001 – Leilão de propostas
https://docs.dataprev.gov.br/wp-content/uploads/2025/03/Manual-de-Comunicacao-%E2%80%93-001-Leilao-de-propostas-%E2%80%93-Credito-Trabalhador.pdf 


codigoSolicitante
dataHoraInicio
dataHoraFim
nroPagina


Manual de Comunicação – 002 – Autorização e consulta do trabalhador
Manual de Comunicação – 003 – Gestão de consignações
Manual de Comunicação – 004 – Envio e consulta de informações de contrato
Manual de Comunicação – 005 – Consultas, escriturações e repasses
Manual de Comunicação – 006 – Renegociação de contratos
Manual de Comunicação – 007 – Gestão de Empréstimos Legados
Manual de Comunicação – 008 – Refinanciamento e Portabilidade
Swagger das novas operações
Manual de Comunicação – 009 – Troca de Titularidade
Manual de Comunicação – 010 – Serviços de Tombamento Compulsório
Manual de Comunicação – 011 – Propostas de Portabilidade


https://docs.dataprev.gov.br/docs/e-consignado/guia-completo-integracao-apis-wso2-4-1/ 

---

### `fluxo sequencial`

| Método | Dominio | Endpoint | Objetivo |
|---------|-----------|-----------|------------|
| GET | Topazio | `/eventos/obter-propostas` | a cada 5 segundos, disparar por timer o serviço de consumo na dataprev |
| GET | DataPrev | `/propostas-ctps/solicitacoes-trabalhador-paginado` | obter todas as propostas atuais |